# Mind + Body
Feeding the body and the brain.

## What we're avoiding
- Staying stuck
- More **debt**

![car](images/car.png)

Some closing thought with a [link](https://example.com).
